 <?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\TheLoai;
use App\Comment;

Route::get('/', function () {
    return view('admin.login');
});

// Route::get('trangchu',function(){
// 	return view('pages.trangchu');
// });

// Route::get('','PagesController@home');
Route::get('home','PagesController@home');
Route::get('contact','PagesController@contact');
Route::get('loaitailieu/{id}/{TenKhongDau}.html','PagesController@loaitailieu');
Route::get('tailieu/{id}/{TieuDeKhongDau}.html','PagesController@tailieu');

// Route::get('/{keywords}',function(){
// 	return view('admin.login');
// })->where(['keywords'=>'[A-Za-z0-9]+']);

// Upload file demo
Route::get('uploadFile',function(){
	return view('pages.detail');
});
Route::post('postFile',['as'=>'postFile','uses'=>'PagesController@postFile']);

// Download file demo
Route::get('downFile','PagesController@downFile');

// OS Command Injection
Route::get('osCommand',function(){
	return view('pages.detail');
});
Route::post('postCommand',['as'=>'postCommand','uses'=>'PagesController@postCommand']);

// Route Admin
Route::get('admin','UserController@getDangnhapAdmin');
Route::get('admin/{keywords}',function(){
	return view('admin.login');
})->where(['keywords'=>'[A-Za-z0-9]+']);

Route::get('admin/login','UserController@getDangnhapAdmin');
Route::post('admin/login','UserController@postDangnhapAdmin');
Route::get('admin/logout','UserController@getDangxuatAdmin');


//Route dang nhap nguoi dung thuong
Route::get('login','PagesController@getDangnhap');
Route::post('login','PagesController@postDangnhap');
Route::get('logout','PagesController@getDangxuat');
Route::get('register','PagesController@getDangky');
Route::post('register','PagesController@postDangky');

Route::get('contact','PagesController@contact');
Route::get('detail','PagesController@detail');

Route::get('accounts','PagesController@getAccounts');
Route::post('accounts','PagesController@postAccounts');

Route::post('search','PagesController@search');

Route::post('comment/{id}','CommentController@postComment');

Route::get('upload/tailieu/','PagesController@home');
Route::get('/upload/{keywords}',function(){
	return view('admin.login');
})->where(['keywords'=>'[A-Za-z0-9]+']);

//Group ADMIN - Phan quyen truy cap site admin
Route::group(['prefix'=>'admin','middleware'=>'adminLogin'],function(){

	// Route::get('upload/','PagesController@home');

	Route::group(['prefix'=>'theloai'],function(){
		Route::get('danhsach','TheLoaiController@getDanhsach');
		
		Route::get('edit/{id}','TheLoaiController@getSua');
		Route::post('edit/{id}','TheLoaiController@postSua');

		Route::get('add','TheLoaiController@getThem');
		Route::post('add','TheLoaiController@postThem');

		Route::get('delete/{id}','TheLoaiController@getXoa');
	});

	//Route Group Loại tài liệu
	Route::group(['prefix'=>'loaitailieu'],function(){
		Route::get('danhsach','LoaiTaiLieuController@getDanhsach');
		
		Route::get('edit/{id}','LoaiTaiLieuController@getSua');
		Route::post('edit/{id}','LoaiTaiLieuController@postSua');

		Route::get('add','LoaiTaiLieuController@getThem');
		Route::post('add','LoaiTaiLieuController@postThem');

		Route::get('delete/{id}','LoaiTaiLieuController@getXoa');
	});

	//Route Group Tài liệu
	Route::group(['prefix'=>'tailieu'],function(){
		
		Route::get('danhsach','TaiLieuController@getDanhsach');

		Route::get('edit/{id}','TaiLieuController@getSua');
		Route::post('edit/{id}','TaiLieuController@postSua');

		Route::get('add','TaiLieuController@getThem');
		Route::post('add','TaiLieuController@postThem');

		Route::get('delete/{id}','TaiLieuController@getXoa');
	});

	//Route Group Comment
	Route::group(['prefix'=>'comment'],function(){
		Route::get('delete/{id}/{idTaiLieu}','CommentController@getXoa');
		Route::get('edit/{id}/{idTaiLieu}','CommentController@getSua');
	});

	//Route Group Ajax để liệt kê danh sách loại tài liệu ứng với thể loại tương ứng.
	Route::group(['prefix'=>'ajax'],function(){
		Route::get('loaitailieu/{idTheLoai}','AjaxController@getLoaiTaiLieu');
	});

	//Route Group Slide nổi bật trang chủ.
	Route::group(['prefix'=>'slide'],function(){
		Route::get('danhsach','SlidersController@getDanhsach');

		Route::get('edit/{id}','SlidersController@getSua');
		Route::post('edit/{id}','SlidersController@postSua');

		Route::get('add','SlidersController@getThem');
		Route::post('add','SlidersController@postThem');

		Route::get('delete/{id}','SlidersController@getXoa');
	});

	//Route Group User
	Route::group(['prefix'=>'user'],function(){
		Route::get('danhsach','UserController@getDanhsach');

		Route::get('edit/{id}','UserController@getSua');
		Route::post('edit/{id}','UserController@postSua');

		Route::get('add','UserController@getThem');
		Route::post('add','UserController@postThem');

		Route::get('delete/{id}','UserController@getXoa');
	});
});