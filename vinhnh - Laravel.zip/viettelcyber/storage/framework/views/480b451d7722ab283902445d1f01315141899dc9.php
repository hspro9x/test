<?php $__env->startSection('content'); ?>

<!-- Page Content -->
<div class="container">
    <div class="row">
        <!-- Blog Post Content Column -->
        <div class="col-lg-9">
            <!-- Blog Post -->
            <!-- Title -->
            <h1><?php echo e($tailieu->TieuDe); ?></h1>
            <!-- Author -->
            <p class="lead">
                bởi <a href="home">admin</a>
            </p>    
            <!-- Preview Image -->
            <img class="img-responsive" src="upload/tailieu/images/<?php echo e($tailieu->Hinh); ?>" alt="">
            <!-- Date/Time -->
            <br><p><span class="glyphicon glyphicon-time"></span> <?php echo e($tailieu->created_at); ?></p>
            <hr>
            <!-- Post Content -->
            <p class="lead">
                <?php echo $tailieu->TomTat; ?> 
            </p>

            <td>
                <a href="upload/tailieu/<?php echo e($tailieu->Teptin); ?>">
                    <button type="button"> Tài liệu đính kèm </button>
                </a>
            </td>
            <hr>
            <!-- Blog Comments -->
            <!-- Comments Form -->
            
            
            <?php if(Auth::user()): ?>
            <div class="well">
                <?php if(session('vmessage')): ?>
                    <?php echo e(session('vmessage')); ?>

                <?php endif; ?>
                <h4>Bình luận tại đây <span class="glyphicon glyphicon-pencil"></span></h4>
                <form action="comment/<?php echo e($tailieu->id); ?>" method="POST" role="form">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <div class="form-group">
                        <textarea class="form-control" name="NoiDung" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary"> Gửi bình luận</button>
                </form>
            </div>
            <?php endif; ?>
            <hr>

            <!-- Posted Comments -->
            <!-- Comment -->
            <?php $__currentLoopData = $tailieu->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $binhluan): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="media">
                <a class="pull-left" href="thanhvien/<?php echo e($binhluan->user->id); ?>">
                    <img class="media-object" src="http://placehold.it/64x64" alt="">
                </a>
                <div class="media-body">
                    
                    <!-- XSS tai $binhluan->user->name -->
                    <h4 class="media-heading"><?php echo $binhluan->user->name; ?>/
                        <small><?php echo e($binhluan->created_at); ?></small>
                    </h4>
                    <?php echo e($binhluan->NoiDung); ?>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>

        <!-- Blog Sidebar Widgets Column -->
        <div class="col-md-3">

            <div class="panel panel-default">
                <div class="panel-heading"><b>Tài liệu liên quan</b></div>
                <div class="panel-body">
                    <?php $__currentLoopData = $tllienquan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <!-- item -->
                    <div class="row" style="margin-top: 10px;">
                        <div class="col-md-5">
                            <a href="tailieu/<?php echo e($tt->id); ?>/<?php echo e($tt->TieuDeKhongDau); ?>.html">
                                <img class="img-responsive" src="upload/tailieu/<?php echo e($tt->Hinh); ?>" alt="">
                            </a>
                        </div>
                        <div class="col-md-7">
                            <a href="tailieu/<?php echo e($tt->id); ?>/<?php echo e($tt->TieuDeKhongDau); ?>.html"><b><?php echo e($tt->TieuDe); ?></b></a>
                        </div>
                        <p><?php echo e($tt->TomTat); ?></p>
                        <div class="break"></div>
                    </div>
                    <!-- end item -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading"><b>Tài liệu nổi bật</b></div>
                <div class="panel-body">
                    <?php $__currentLoopData = $tlnoibat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <!-- item -->
                    <div class="row" style="margin-top: 10px;">
                        <div class="col-md-5">
                            <a href="tailieu/<?php echo e($tt->id); ?>/<?php echo e($tt->TieuDeKhongDau); ?>.html">
                                <img class="img-responsive" src="upload/tailieu/<?php echo e($tt->Hinh); ?>" alt="">
                            </a>
                        </div>
                        <div class="col-md-7">
                            <a href="tailieu/<?php echo e($tt->id); ?>/<?php echo e($tt->TieuDeKhongDau); ?>.html"><b><?php echo e($tt->TieuDe); ?></b></a>
                        </div>
                        <p><?php echo e($tt->TomTat); ?></p>
                        <div class="break"></div>
                    </div>
                    <!-- end item -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->
</div>
<!-- end Page Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>