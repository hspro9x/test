<?php $__env->startSection('content'); ?>

<!-- Page Content -->
<div class="container">

	<!-- slider -->
	<div class="row carousel-holder">
        <div class="col-md-2">
        </div>
        <div class="col-md-8">
            <div class="panel panel-default">
            	<?php if(Auth::user()): ?>

			  	<div class="panel-heading">Thông tin tài khoản</div>
			  	<div class="panel-body">


			  		<?php if(count($errors) > 0): ?>
			  			<div class="alert alert-danger">
			  				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			  					<?php echo e($err); ?><br>
			  				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			  			</div>
			  		<?php endif; ?>

			  		<?php if(session('vmessage')): ?>
			  			<div class="alert alert-success">
			  				<?php echo e(session('vmessage')); ?>

			  			</div>
			  		<?php endif; ?>

			    	<form action="accounts" method="POST">
			    		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
			    		<div>
			    			<label>Họ tên</label>
						  	<input type="text" class="form-control" placeholder="Username" name="name" aria-describedby="basic-addon1" value="<?php echo Auth::user()->name; ?>">
						</div>
						<br>
						<div>
			    			<label>Email</label>
						  	<input type="email" class="form-control" placeholder="Email" name="email" aria-describedby="basic-addon1"
						  	readonly value="<?php echo e(Auth::user()->email); ?>"
						  	>
						</div>
						<br>	
						<div>
							<input type="checkbox" id="changePassword" name="changePassword">
			    			<label>Đổi mật khẩu</label>
						  	<input type="password" class="form-control password" name="password" aria-describedby="basic-addon1" disabled>
						</div>
						<br>
						<div>
			    			<label>Nhập lại mật khẩu</label>
						  	<input type="password" class="form-control password" name="repassword" aria-describedby="basic-addon1" disabled>
						</div>
						<br>
						<button type="submit" class="btn btn-default">Sửa
						</button>

			    	</form>
			  	</div>
			  	<?php endif; ?>
			</div>
				
        </div>
        <div class="col-md-2">
        </div>
    </div>
    <!-- end slide -->
</div>
<!-- end Page Content -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $("#changePassword").change(function(){
                if($(this).is(":checked")){ //Kiểm tra checkbox có được check hay không
                    $(".password").removeAttr('disabled');
                }else{
                    $(".password").attr('disabled','');
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>