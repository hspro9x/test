
<div class="col-md-3 ">
    <ul class="list-group" id="menu">
        <li href="#" class="list-group-item menu1 active">
        	Danh sách thể loại
        </li>


        <?php $__currentLoopData = $theloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tl): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if(count($tl->loaitailieu) >= 0): ?>
            <li href="#" style="color:blue" class="list-group-item menu1">
            	<i><?php echo e($tl->Ten); ?></i>
            </li>
            <ul>
                <?php $__currentLoopData = $tl->loaitailieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        		<li class="list-group-item">
        			<a href="loaitailieu/<?php echo e($lt->id); ?>/<?php echo e($lt->TenKhongDau); ?>.html"><?php echo e($lt->Ten); ?></a>
        		</li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </ul>
</div>