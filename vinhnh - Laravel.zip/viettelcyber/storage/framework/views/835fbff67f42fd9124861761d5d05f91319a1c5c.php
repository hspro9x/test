<?php $__env->startSection('content'); ?>

<!-- Page Content -->

<div class="container">
	<?php echo $__env->make('layout.slide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="space20"></div>


    <div class="row main-left">
    	<?php echo $__env->make('layout.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="col-md-9">
            <div class="panel panel-default">            
            	<div class="panel-heading" style="background-color:#337AB7; color:white;" >
            		<h2 style="margin-top:0px; margin-bottom:0px;">Tài liệu</h2>
            	</div>

            	<div class="panel-body">
            		<?php $__currentLoopData = $theloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tl): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            			<?php if(count($tl->loaitailieu) > 0): ?>    			
	            		<!-- item -->
					    <div class="row-item row">
		                	<h3>
		                		
		                		<a href="#"><?php echo e($tl->Ten); ?></a> | 
		                		<?php $__currentLoopData = $tl->loaitailieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>	
		                		<small><a href="loaitailieu/<?php echo e($lt->id); ?>/<?php echo e($lt->TenKhongDau); ?>.html"><i><?php echo e($lt->Ten); ?></i></a> /</small>
		                		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		                	</h3>
		                	<?php
		                		$data = $tl->tailieu->where('NoiBat',1)->sortByDesc('created_at')->take(5);
		                		$tin1 = $data->shift();
		                	?>

		                	<div class="col-md-8 border-right">
		                		<div class="col-md-5">
		                			<?php if(isset($tin1)): ?>
			                        <a href="tailieu/<?php echo e($tin1['id']); ?>/<?php echo e($tin1['TieuDeKhongDau']); ?>.html">	                        	
			                            <img class="img-responsive" src="upload/tailieu/images/<?php echo e($tin1['Hinh']); ?>" alt="">
			                        </a>
			                        <?php endif; ?>
			                    </div>
			                    
			                    <div class="col-md-7">
			                    	<?php if(isset($tin1)): ?>
			                        <h3><?php echo e($tin1['TieuDe']); ?></h3>
			                        <p><?php echo e($tin1['TomTat']); ?></p>
			                        <a class="btn btn-primary" href="tailieu/<?php echo e($tin1['id']); ?>/<?php echo e($tin1['TieuDeKhongDau']); ?>.html">Xem thêm<span class="glyphicon glyphicon-chevron-right"></span></a>
			                        <?php endif; ?>
								</div>
		                	</div>

		                	
		                    <?php if(isset($data)): ?>
							<div class="col-md-4">								
								<?php $__currentLoopData = $data->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tailieu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<a href="tailieu/<?php echo e($tailieu['id']); ?>/<?php echo e($tailieu['TieuDeKhongDau']); ?>.html">
									<h4>
										<span class="glyphicon glyphicon-list-alt"></span>
										<?php echo e($tailieu['TieuDe']); ?>

									</h4>
								</a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
							</div>
							<?php endif; ?>	
							<div class="break"></div>
		                </div>
		                <!-- end item -->
	                	<?php endif; ?>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>
            </div>
    	</div>
    </div>
    <!-- /.row -->
</div>

<!-- end Page Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>