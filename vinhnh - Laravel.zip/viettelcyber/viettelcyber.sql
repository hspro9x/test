-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 10, 2020 lúc 04:13 PM
-- Phiên bản máy phục vụ: 10.4.13-MariaDB
-- Phiên bản PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `laravel`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `comment`
--

CREATE TABLE `comment` (
  `id` int(10) UNSIGNED NOT NULL,
  `idUser` int(10) UNSIGNED NOT NULL,
  `idTaiLieu` int(10) UNSIGNED NOT NULL,
  `NoiDung` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `comment`
--

INSERT INTO `comment` (`id`, `idUser`, `idTaiLieu`, `NoiDung`, `created_at`, `updated_at`) VALUES
(101, 1, 1, 'Được', '2020-06-16 07:25:59', '2020-06-16 07:25:59'),
(104, 2, 1015, 'Tài liệu này hay quá!', '2020-10-13 16:59:44', '2020-10-13 16:59:44'),
(105, 3, 1013, 'Vài ba cái tài liệu vớ vẫn :(', '2020-10-14 05:39:42', '2020-10-14 05:39:42'),
(106, 3, 1013, 'Vài ba cái tài liệu vớ vẫn :(', '2020-10-14 05:50:55', '2020-10-14 05:50:55'),
(107, 3, 1013, 'Vài ba cái tài liệu vớ vẫn :(', '2020-10-14 05:51:18', '2020-10-14 05:51:18'),
(108, 3, 1013, 'Vài ba cái tài liệu vớ vẫn :(', '2020-10-14 05:52:14', '2020-10-14 05:52:14'),
(109, 2, 1013, 'Cảm ơn Sơn đã còm men ở đây!', '2020-10-14 06:23:41', '2020-10-14 06:23:41'),
(110, 3, 1, 'Hi hi ! ', '2020-10-25 08:35:41', '2020-10-25 08:35:41'),
(111, 3, 1011, 'Cảm ơn admin nhiều nhé! ', '2020-10-25 08:35:57', '2020-10-25 08:35:57');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loaitailieu`
--

CREATE TABLE `loaitailieu` (
  `id` int(10) UNSIGNED NOT NULL,
  `idTheLoai` int(10) UNSIGNED NOT NULL,
  `Ten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TenKhongDau` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `loaitailieu`
--

INSERT INTO `loaitailieu` (`id`, `idTheLoai`, `Ten`, `TenKhongDau`, `created_at`, `updated_at`) VALUES
(1, 1, 'VIỄN THÔNG  ', 'vien-thong', NULL, '2020-09-28 05:19:01'),
(2, 1, 'ĐA PHƯƠNG TIỆN (MULTIMEDIA)', 'da-phuong-tien-multimedia-', NULL, '2020-09-28 05:31:39'),
(3, 1, 'CÔNG NGHỆ THÔNG TIN ', 'cong-nghe-thong-tin', NULL, '2020-09-28 05:21:11'),
(4, 1, 'KHOA HỌC CƠ BẢN', 'khoa-hoc-co-ban', NULL, '2020-09-28 05:27:41'),
(5, 1, 'KỸ NĂNG MỀM', 'ky-nang-mem', NULL, '2020-09-28 08:41:18'),
(6, 1, 'KỸ THUẬT ĐIỆN TỬ', 'ky-thuat-dien-tu', NULL, '2020-09-28 08:54:01'),
(7, 1, 'MARKETING', 'marketing', NULL, '2020-09-28 08:54:22'),
(8, 1, 'QUẢN TRỊ KINH DOANH', 'quan-tri-kinh-doanh', NULL, '2020-09-28 08:55:51'),
(9, 1, 'TÀI CHÍNH - KẾ TOÁN', 'tai-chinh-ke-toan', NULL, '2020-09-28 05:49:01'),
(38, 2, 'BÀI ĐĂNG TẠP CHÍ', 'bai-dang-tap-chi', '2020-09-28 05:29:38', '2020-09-28 05:29:38'),
(39, 2, 'HỘI NGHỊ, HỘI THẢO QUỐC TẾ', 'hoi-nghi-hoi-thao-quoc-te', '2020-09-28 05:29:47', '2020-09-28 05:29:47'),
(40, 2, 'HỘI NGHỊ, HỘI THẢO TRONG NƯỚC', 'hoi-nghi-hoi-thao-trong-nuoc', '2020-09-28 05:29:55', '2020-09-28 05:29:55'),
(41, 2, 'THÔNG BÁO KẾT QUẢ NCKH CỦA CÁC VIỆN, TRUNG TÂM', 'thong-bao-ket-qua-nckh-cua-cac-vien-trung-tam', '2020-09-28 05:30:02', '2020-09-28 05:30:02'),
(42, 2, 'ĐỀ TÀI NGHIÊN CỨU KHOA HỌC', 'de-tai-nghien-cuu-khoa-hoc', '2020-09-28 05:30:08', '2020-09-28 05:30:08'),
(43, 4, 'Công nghệ thông tin', 'cong-nghe-thong-tin', '2020-10-05 15:15:22', '2020-10-05 15:15:22'),
(44, 4, 'Điện tử', 'dien-tu', '2020-10-05 15:15:34', '2020-10-05 15:15:34'),
(46, 4, 'Toán rời rạc 1', 'toan-roi-rac-1', '2020-10-05 15:16:59', '2020-10-05 15:16:59'),
(47, 4, 'Toán cao cấp 1', 'toan-cao-cap-1', '2020-10-05 15:17:11', '2020-10-05 15:17:11');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2020_06_09_021546_Tao_TheLoai', 2),
('2020_06_09_021610_Tao_LoaiTaiLieu', 3),
('2020_06_09_021813_Tao_TaiLieu', 4),
('2020_06_09_022526_Tao_Slide', 5),
('2020_06_09_022904_Tao_Comment', 6);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `slide`
--

CREATE TABLE `slide` (
  `id` int(10) UNSIGNED NOT NULL,
  `Ten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Hinh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NoiDung` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `slide`
--

INSERT INTO `slide` (`id`, `Ten`, `Hinh`, `NoiDung`, `link`, `created_at`, `updated_at`) VALUES
(1, 'Slide 1', 'zDuiOHoJoF6pfqP2G8YP_1.jpg', 'Slide 1', 'https://viettelcybersecurity.com', '2020-10-05 14:26:01', '2020-10-05 14:26:01'),
(2, 'Slide 2', 'wHH9zvBguTtRAvGUzNtu_JhwC9SM47I9npwNT1lhw_11.jpg', 'Slide 2', 'https://viettelcybersecurity.com', '2020-10-05 14:26:48', '2020-10-05 14:26:48'),
(3, 'Slide 3', 'Ta25prLzunMCKJeO7hod_bg-404.jpg', 'Slide 3', 'https://viettelcybersecurity.com', '2020-10-05 14:32:43', '2020-10-05 14:32:43');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `theloai`
--

CREATE TABLE `theloai` (
  `id` int(10) UNSIGNED NOT NULL,
  `Ten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TenKhongDau` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `theloai`
--

INSERT INTO `theloai` (`id`, `Ten`, `TenKhongDau`, `created_at`, `updated_at`) VALUES
(1, 'Bài giảng học viện', 'bai-giang-hoc-vien', NULL, '2020-09-28 03:56:34'),
(2, 'Nghiên cứu khoa học', 'nghien-cuu-khoa-hoc', NULL, '2020-10-05 15:11:32'),
(3, 'E-Books', 'e-books', NULL, '2020-09-28 03:53:41'),
(4, 'Giáo trình', 'giao-trinh', NULL, '2020-09-28 03:54:01'),
(5, 'Luận văn - Luận án', 'luan-van-luan-an', NULL, '2020-09-28 03:54:27'),
(6, 'Tạp chí', 'tap-chi', NULL, '2020-10-05 15:11:47'),
(7, 'Thông tin - Thư viện', 'thong-tin-thu-vien', NULL, '2020-09-28 03:55:44'),
(8, 'Sách truyện Tiếng Việt', 'sach-truyen-tieng-viet', NULL, '2020-09-28 03:57:35'),
(9, 'Sách truyện Tiếng Anh', 'sach-truyen-tieng-anh', NULL, '2020-09-28 03:57:47');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tailieu`
--

CREATE TABLE `tailieu` (
  `id` int(10) UNSIGNED NOT NULL,
  `TieuDe` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TieuDeKhongDau` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TomTat` text COLLATE utf8_unicode_ci NOT NULL,
  `NoiDung` longtext COLLATE utf8_unicode_ci NOT NULL,
  `Hinh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Teptin` varchar(255) CHARACTER SET utf8 NOT NULL,
  `NoiBat` int(11) NOT NULL DEFAULT 0,
  `SoLuotXem` int(11) NOT NULL DEFAULT 0,
  `idLoaiTaiLieu` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tailieu`
--

INSERT INTO `tailieu` (`id`, `TieuDe`, `TieuDeKhongDau`, `TomTat`, `NoiDung`, `Hinh`, `Teptin`, `NoiBat`, `SoLuotXem`, `idLoaiTaiLieu`, `created_at`, `updated_at`) VALUES
(1, 'Tiêu Đề', 'Tieu-De', 'Tóm tắt', 'Đây là nội dung', 'FPT-2.jpg', '', 1, 0, 1, '2020-10-03 06:02:51', '2020-10-03 06:02:51'),
(1008, 'LẬP TRÌNH AN TOÀN', 'lap-trinh-an-toan', 'LẬP TRÌNH AN TOÀN', 'Đây là nội dung', 'lAcpNfYU0YdeB2AQMAHP_unnamed.jpg', '', 1, 0, 3, '2020-10-03 06:02:51', '2020-10-03 06:02:51'),
(1010, 'TOÁN RỜI RẠC 1', 'toan-roi-rac-1', 'BÀI GIẢNG TOÁN RỜI RẠC 1', 'Đây là nội dung', 'vOXmobnD4864kfKk3ZnK_image_4370645.jpg', '', 1, 0, 4, '2020-10-04 06:32:58', '2020-10-04 06:32:58'),
(1011, 'PHOTOSHOP', 'photoshop', 'PHOTOSHOP', 'Đây là nội dung', 'gNA0gdv0Frmy7dbEQXPS_Ta25prLzunMCKJeO7hod_bg-404.jpg', '', 1, 0, 2, '2020-10-07 03:58:01', '2020-10-07 03:58:01'),
(1012, 'CROSS-SITE SCRIPTING', 'cross-site-scripting', 'CROSS-SITE SCRIPTING', 'Đây là nội dung', 'BC2wiUWTvfUH83B6Sq8g_cross-site-scripting-xss.jpg', '', 1, 0, 3, '2020-10-07 03:58:28', '2020-10-07 04:47:52'),
(1013, 'LOCALFILE INCLUSION', 'localfile-inclusion', 'LOCALFILE INCLUSION', 'Đây là nội dung', 'b9UW1i0Myqaz7c69UUMO_lfi.jpeg', '', 1, 0, 38, '2020-10-07 03:58:44', '2020-10-07 04:24:12'),
(1014, 'TOÁN HỌC 1', 'toan-hoc-1', 'TOÁN HỌC 1', 'Đây là nội dung', '7BDleWtRyzHmH5V6hJpg_math-1.jpg', '', 1, 0, 43, '2020-10-07 03:59:02', '2020-10-07 04:26:43'),
(1015, 'CHIẾN LƯỢC MARKETING', 'chien-luoc-marketing', 'CHIẾN LƯỢC MARKETING', '', 'N5wfzS3YrpvaRHNP0MOD_000_Was3710642.jpg', '', 1, 0, 7, '2020-10-07 04:04:15', '2020-10-25 09:58:49'),
(1016, 'CODE CODE', 'code-code', 'CODE FOR LIFE.PDF', '', '', 'eUfKVhZu6dn1rrrRdFoo_Code.pdf', 0, 0, 39, '2020-10-25 10:10:15', '2020-10-25 10:10:15');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quyen` int(11) NOT NULL DEFAULT 0,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `sodienthoai` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `quyen`, `password`, `remember_token`, `created_at`, `updated_at`, `sodienthoai`) VALUES
(1, 'Nguyễn Huy Vinh', 'vinhnh@gmail.com', 1, '$2y$10$GJlC4p39DYx1ZW7rWHnYNeNKdFXniZO3V8.jGyrHLBaMpLDr8vcT.', 'zSoHt1U4Z57HByHT94c21DVuQKbsyYw5NX6uim3i0s6QmETegdV6W67M2vz6', '2020-06-09 03:05:09', '2020-11-10 12:04:13', '0365314629'),
(2, 'Nguyễn Đăng Văn', 'vannd@gmail.com', 0, '$2y$10$VSYdTPHgu6iQ0NBouPmQTe2nxENOouLMEcjQiG54cFNlUbEInurxC', 'E91KDj1FEfh4cp7obTF38TnQ5uEem5fW8iUDAyXZEGRpxuNv02esqS4Hf8Je', '2020-06-09 03:05:09', '2020-10-14 06:46:49', '0917263186'),
(3, 'Nguyễn Hồng Sơn', 'sonnh@gmail.com', 0, '$2y$10$DES3NL8tozlU99dvO9o4lOfYyYcaM9n86gJcJV5.fz2G8b6qLa6Gq', 'hb0J0XayA1W6OTNo0RB3INVHhCGpzMJSFVaZnHHNFsHiYRNMWgo125IBQmCy', '2020-06-09 03:05:09', '2020-10-25 08:36:27', '0365314666'),
(4, 'Long Nguyễn', 'longnhv@gmail.com', 0, '$2y$10$xqfx9motmrCAEuEjCyQroOo/eFqum1hPhgwnz5LSLkhdyGHvf6l8O', NULL, '2020-06-09 03:05:10', NULL, '0123132132');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comment_iduser_foreign` (`idUser`),
  ADD KEY `comment_idtailieu_foreign` (`idTaiLieu`);

--
-- Chỉ mục cho bảng `loaitailieu`
--
ALTER TABLE `loaitailieu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `loaitailieu_idtheloai_foreign` (`idTheLoai`);

--
-- Chỉ mục cho bảng `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Chỉ mục cho bảng `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `theloai`
--
ALTER TABLE `theloai`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tailieu`
--
ALTER TABLE `tailieu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tailieu_idloaitailieu_foreign` (`idLoaiTaiLieu`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT cho bảng `loaitailieu`
--
ALTER TABLE `loaitailieu`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT cho bảng `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT cho bảng `theloai`
--
ALTER TABLE `theloai`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `tailieu`
--
ALTER TABLE `tailieu`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1017;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_idtailieu_foreign` FOREIGN KEY (`idTaiLieu`) REFERENCES `tailieu` (`id`),
  ADD CONSTRAINT `comment_iduser_foreign` FOREIGN KEY (`idUser`) REFERENCES `users` (`id`);

--
-- Các ràng buộc cho bảng `loaitailieu`
--
ALTER TABLE `loaitailieu`
  ADD CONSTRAINT `loaitailieu_idtheloai_foreign` FOREIGN KEY (`idTheLoai`) REFERENCES `theloai` (`id`);

--
-- Các ràng buộc cho bảng `tailieu`
--
ALTER TABLE `tailieu`
  ADD CONSTRAINT `tailieu_idloaitailieu_foreign` FOREIGN KEY (`idLoaiTaiLieu`) REFERENCES `loaitailieu` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
