<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\TheLoai;

class TheLoaiController extends Controller
{
    //
    public function getDanhsach(){
    	$theloai = TheLoai::all();
    	return view('admin.theloai.danhsach',['theloai' => $theloai]);
    }
    public function getThem(){
    	 return view('admin.theloai.add');
    }

    public function postThem(Request $request){
    	// echo $request->Ten;
    	$this->validate($request,
            ['Ten' => 'required|min:5|max:50|unique:TheLoai,Ten'],
            [
                'Ten.unique' => 'Tên thể loại đã tồn tại',
                'Ten.required' => 'Bạn chưa nhập tên thể loại',
                'Ten.min' => 'Tên thể loại quá ngắn (tối thiểu 5 kí tự)',
                'Ten.max' => 'Tên thể loại quá dài (tối đa 50 kí tự)'
            ]);
    	$theloai = new TheLoai;
    	$theloai->Ten = $request->Ten;
    	$theloai->TenKhongDau = changeTitle($request->Ten);
        
        $theloai->save();
        return redirect('admin/theloai/add')->with('vmessage','Thêm thành công');
    }
    public function getSua($id){
    	$theloai = TheLoai::find($id);
        return view('admin.theloai.edit',['theloai'=>$theloai]);
    }

    public function postSua(Request $request,$id){
        $theloai = TheLoai::find($id);

        $this->validate($request,
        [
            'Ten'=>'required|unique:TheLoai,Ten|min:5|max:50'
        ],
        [
            'Ten.unique' => 'Tên thể loại đã tồn tại',
            'Ten.required' => 'Bạn chưa nhập tên thể loại',
            'Ten.min' => 'Tên thể loại quá ngắn (tối thiểu 5 kí tự)',
            'Ten.max' => 'Tên thể loại quá dài (tối đa 50 kí tự)'
        ]);

        $theloai->Ten = $request->Ten;
        $theloai->TenKhongDau = changeTitle($request->Ten);
        $theloai->save();

        return redirect('admin/theloai/edit/'.$theloai->id)->with('vmessage','Đã sửa thành công');
    }
    
    public function getXoa($id){
    	$theloai = TheLoai::find($id);
        $theloai->delete();
        // return redirect('admin/theloai/danhsach')->with('vmessage','Đã xóa thành công'.$theloai->Ten);
        return redirect('admin/theloai/danhsach')->with('vmessage','Đã xóa thành công: '.$theloai->Ten);
    }
    
}