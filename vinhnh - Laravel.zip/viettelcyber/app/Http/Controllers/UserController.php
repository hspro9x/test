<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Http\Requests;
use App\User;

class UserController extends Controller
{
    //
    public function getDanhsach(){
    	$user = User::all();
    	return view('admin.user.danhsach',['user'=>$user]);
    }

    public function getThem(){
    	return view('admin.user.add');
    }

    public function postThem(Request $request){
    	$this->validate($request,
    		[
    			'name'=>'required|min:5|max:50',
                'email'=> 'required|email|unique:users,email',
    			'sodienthoai'=>'required|min:10|max:10',
				'password' => 'required|min:8|max:30|regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\x])(?=.*[!@$#%]).*$/',
    			'repassword'=>'required|same:password'
    		],
    		[
    			'name.required' => 'Name is not valid',
    			'name.min' => 'Name is not valid',
    			'name.max' => 'Name is not valid',
    			'email.email' => 'Email is not valid',
    			'email.required' => 'Email is not valid',
    			'email.unique' => 'Email da ton tai',
				'password.required' => 'Password is not valid',
				'password.regex' => 'Password is not valid',
    			'password.min' => 'Password is not valid',
    			'password.max' => 'Password is not valid'
    		]);

    	$user = new User;
    	$user->name = $request->name;
    	$user->email = $request->email;
    	$user->sodienthoai = $request->sodienthoai;
    	$user->password = bcrypt($request->password);
    	$user->quyen = $request->quyen;

    	$user->save();

        return redirect('admin/user/danhsach')->with('vmessage','Success !!!');
    }

    public function getSua($id){

    	$user = User::find($id);
    	return view('admin.user.edit',['user'=>$user]);
    }

    public function postSua(Request $request, $id){
    	$this->validate($request,
    		[
    			'sodienthoai'=>'required|min:10|max:10',
    		],
    		[
    			'sodienthoai.required' => 'Bạn chưa nhập số điện thoại',
    			'sodienthoai.min' => 'Số điện thoại sai định dạng',
				'sodienthoai.max' => 'Số điện thoại sai định dạng',
				'sodienthoai.regex' => 'Số điện thoại sai định dạng',
    		]);
    	
    	$user = User::find($id);
    	$user->sodienthoai = $request->sodienthoai;
    	$user->quyen = $request->quyen;

    	if($request->changePassword == "on"){
    	$this->validate($request,
    		[
				'password' => 'required|min:8|max:30|regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\x])(?=.*[@+!$#%]).*$/',
    			'repassword'=>'required|same:password'
    		],
    		[
    			'password.required' => 'Password is not valid',
    			'password.min' => 'Password is not valid',
    			'password.max' => 'Password is not valid',
    			'repassword.required' => 'Repassword is not valid',
    			'repassword.same' => 'Repassword is not valid'
    		]);

    		$user->password = bcrypt($request->password);
    	}

    	$user->save();
        return redirect('admin/user/edit/'.$id)->with('vmessage','Success !!!');
    }

    public function getXoa($id){
    	$user = User::find($id);
    	$user->delete();

        return redirect('admin/user/danhsach')->with('vmessage','Success !!!');
    }

    public function getDangnhapAdmin(){
    	return view('admin.login');
    }
    public function postDangnhapAdmin(Request $request){
    	$this->validate($request,
    		[
    			'email'=>'required',
    			'password'=>'required'
    		],
    		[
    			'email.required'=>'Email or Password is not valid!',
    			'password.required'=>'Email or Password is not valid!'
    		]);

    	if(Auth::attempt(['email'=>$request->email,'password'=>$request->password])){
    		return redirect('admin/theloai/danhsach');
    	}else{
    		return redirect('admin/login')->with('errormessage','Email or Password is not valid!');
    	}
    }

    public function getDangxuatAdmin(){  	
    	Auth::logout();
    	return redirect('admin/login');
    }
}
