<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\TheLoai;
use App\LoaiTaiLieu;

class LoaiTaiLieuController extends Controller
{
    //
    public function getDanhsach(){
    	$loaitailieu = LoaiTaiLieu::all();
    	return view('admin.loaitailieu.danhsach',['loaitailieu' => $loaitailieu]);
    }
    public function getThem(){

    	$theloai = TheLoai::all(); 	
    	return view('admin.loaitailieu.add',['theloai'=>$theloai]);
    }

    public function postThem(Request $request){
    	// echo $request->Ten;
    	$this->validate($request,
            [
            	'Ten' => 'required|min:5|max:50|unique:LoaiTaiLieu,Ten',
            	'TheLoai' => 'required'
        	],
            [	
            	'TheLoai.required'=>'Bạn chưa chọn thể loại',
                'Ten.unique' => 'Tên loại tài liệu đã tồn tại',
                'Ten.required' => 'Bạn chưa nhập tên loại tài liệu',
                'Ten.min' => 'Tên loại tài liệu quá ngắn (tối thiểu 5 kí tự)',
                'Ten.max' => 'Tên loại tài liệu quá dài (tối đa 50 kí tự)'
            ]);
    	$loaitailieu = new LoaiTaiLieu;
    	$loaitailieu->Ten = $request->Ten;
    	$loaitailieu->TenKhongDau = changeTitle($request->Ten);
    	$loaitailieu->idTheLoai = $request->TheLoai;
        //echo changeTitle($request->Ten);
        $loaitailieu->save();
        // $tieude=str_slug($request->Ten,'-');
        return redirect('admin/loaitailieu/add')->with('vmessage','Thêm thành công');
    }
    public function getSua($id){

    	$theloai = TheLoai::all();
    	$loaitailieu = LoaiTaiLieu::find($id);
        return view('admin.loaitailieu.edit',['loaitailieu'=>$loaitailieu,'theloai'=>$theloai]);
    }

    public function postSua(Request $request,$id){
        

        $this->validate($request,
        [
            'Ten'=>'required|unique:LoaiTaiLieu,Ten|min:5|max:50',
            'TheLoai'=>'required'
        ],
        [
        	'TheLoai.required'=>'Bạn chưa chọn thể loại',
            'Ten.unique' => 'Tên loại tài liệu đã tồn tại',
            'Ten.required' => 'Bạn chưa nhập tên loại tài liệu',
            'Ten.min' => 'Tên loại tài liệu quá ngắn (tối thiểu 5 kí tự)',
            'Ten.max' => 'Tên loại tài liệu quá dài (tối đa 50 kí tự)'
        ]);
        
		$loaitailieu = LoaiTaiLieu::find($id);
        $loaitailieu->Ten = $request->Ten;
        $loaitailieu->TenKhongDau = changeTitle($request->Ten);
        $loaitailieu->idTheLoai = $request->TheLoai;
        $loaitailieu->save();

        return redirect('admin/loaitailieu/edit/'.$loaitailieu->id)->with('vmessage','Đã sửa thành công');
    }
    
    public function getXoa($id){
    	$loaitailieu = LoaiTaiLieu::find($id);
        $loaitailieu->delete();
        
        // return redirect('admin/LoaiTaiLieu/danhsach')->with('vmessage','Đã xóa thành công'.$LoaiTaiLieu->Ten);
        return redirect('admin/loaitailieu/danhsach')->with('vmessage','Đã xóa thành công: '.$loaitailieu->Ten);
    }
    
}
