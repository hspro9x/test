<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Comment;
use App\TaiLieu;

class CommentController extends Controller
{

    // public function getDanhSach(){
    //     $comment = Comment::all();
    //     return view('admin.comment.danhsach',['comment'=>$comment]);
    // }

    // public function postComment($article_id,Request $request){
    //     $this->validate($request,
    //         [
    //             'content' => 'required'
    //         ],
    //         [
    //             'content.required' => 'Bạn chưa nhập nội dung'
    //         ]);
    //     $tailieu = TaiLieu::find($article_id);
    //     $comment = new Comment;
    //     $comment->idUser = Auth::user()->id;
    //     $comment->idTaiLieu = $article_id;
    //     $comment->NoiDung = $request->content;
    //     $comment->save();

    //     return redirect('tin-tuc/'.$tailieu->TieuDeKhongDau.'.html')->with('message','Bình Luận đã được đăng!');
    // }

    public function getSua($id){
        $binhluan = Comment::find($id);
        return view('admin.tailieu.edit',['binhluan'=>$binhluan]);
    }

    public function postSua(){

    }
    public function getXoa($id , $idTaiLieu){

        $binhluan=Comment::find($id);
        $binhluan->delete();

        return redirect('admin/tailieu/edit/'.$idTaiLieu)->with('vmessage','Đã xóa bình luận thành công');
    }
    
    public function postComment($id, Request $request){
        $idTaiLieu = $id;
        $tailieu = TaiLieu::find($id);

        $binhluan = new Comment;
        $binhluan->idTaiLieu = $idTaiLieu;
        $binhluan->idUser = Auth::user()->id;
        $binhluan->NoiDung = $request->NoiDung;
        $binhluan->save();

        return redirect('tailieu/'.$id.'/'.$tailieu->TieuDeKhongDau.".html")->with('vmessage','Bạn đã cập nhật bình luận thành công !');
    }

}
