<?php

namespace App\Http\Controllers;

use Illuminate\Support\Str;
use Illuminate\Http\Request;

use App\TheLoai;
use App\TaiLieu;
use App\LoaiTaiLieu;
use App\Comment;
use Input, File;
use DB;

class TaiLieuController extends Controller
{
    //
    public function getDanhsach(){
    	$tailieu = TaiLieu::orderBy('id','DESC')->get();
    	return view('admin.tailieu.danhsach',['tailieu'=>$tailieu]);
    }

    public function getThem(){
        $theloai = TheLoai::all();
        $loaitailieu = LoaiTaiLieu::all();
        return view('admin.tailieu.add',['theloai'=>$theloai,'loaitailieu'=>$loaitailieu]);
    }

    public function postThem(Request $request){
        $this->validate($request,
            [
                'LoaiTaiLieu' => 'required',
                'TieuDe' => 'required|min:5|max:50|unique:TaiLieu,TieuDe',
                'TomTat' => 'required|min:5|max:50'
                // 'NoiDung' => 'required|min:5|max:50'
            ],
            [
                'LoaiTaiLieu.required' => 'Bạn chưa chọn loại tài liệu',
                'TieuDe.required' => 'Bạn chưa nhập tiêu đề tài liệu',
                'TieuDe.min' => 'Tiêu đề quá ngắn (ít nhất 5 kí tự)',
                'TieuDe.max' => 'Tiêu đề quá dài (tối đa 50 kí tự)',
                'TieuDe.unique' => 'Tiêu đề đã tồn tại',
                'TomTat.required' => 'Hãy nhập tóm tắt cho tài liệu',
                'TomTat.min' => 'Tóm tắt quá ngắn (ít nhất 5 kí tự)',
                'TomTat.max' => 'Tóm tắt quá dài (tối đa 50 kí tự)'
                // 'NoiDung.required' => 'Bạn chưa nhập nội dung'
            ]);

        $tailieu = new TaiLieu;
        $tailieu->TieuDe = $request->TieuDe;
        $tailieu->TieuDeKhongDau = changeTitle($request->TieuDe);
        $tailieu->idLoaiTaiLieu = $request->LoaiTaiLieu;
        $tailieu->TomTat = $request->TomTat;
        $tailieu->NoiDung = "";
        $tailieu->NoiBat = $request->NoiBat;
        $tailieu->SoLuotXem = 0;
        
        if($request -> hasFile('Hinh')){
            
            $file = $request->file('Hinh');
            $extension = $file->getClientOriginalExtension();
            // Bo kiem tra extension.
            // if($extension != 'jpg' && $extension != 'png' && $extension != 'gif' && $extension != 'jpeg'){
            //     return redirect('admin/tailieu/add')->with('errormessage','Bạn chỉ được chọn file có định dạng: .jpg, .jpeg, .png, .gif');
            // }

            $name = $file->getClientOriginalName();
            $Hinh = str_random(20)."_". $name;
            
            while(file_exists("upload/tailieu/images".$Hinh)){
                $Hinh = str_random(20)."_". $name;
            }
            
            $file->move("upload/tailieu/images",$Hinh);
            
            $tailieu->Hinh = $Hinh;

            // echo $Hinh;
        }else{
            $tailieu->Hinh = "";
        }

        // Code chức năng upload file tài liệu đính kèm
        // $filett = file tệp tin đính kèm
        if($request -> hasFile('Teptin')){

            $filett = $request->file('Teptin');
            $extensiontt = $filett->getClientOriginalExtension();

            // Bo kiem tra extension.
            // if($extensiontt != 'pdf' && $extensiontt != 'doc' && $extensiontt != 'docx'){
            //     return redirect('admin/tailieu/add')->with('errormessage','Bạn chỉ được chọn file có định dạng: pdf, doc, docx');
            // }

            $namett = $filett->getClientOriginalName();
            $Teptin = str_random(20)."_". $namett;
            
            while(file_exists("upload/tailieu/".$Teptin)){
                $Teptin = str_random(20)."_". $namett;
            }
            
            $filett->move("upload/tailieu",$Teptin);
            
            $tailieu->Teptin = $Teptin;
            // echo $Teptin;
        }else{
            $tailieu->Teptin = "";
        }
 
        $tailieu->save();

        return redirect('admin/tailieu/add')->with('vmessage','Thêm tài liệu thành công !');
    }

    public function getSua($id){

        $theloai = TheLoai::all();
        $loaitailieu = LoaiTaiLieu::all();
        $tailieu = TaiLieu::find($id);
        // $comment = Comment::find($id);

        return view('admin.tailieu.edit',['tailieu'=>$tailieu,'theloai'=>$theloai,'loaitailieu'=>$loaitailieu]);
    }

    public function postSua(Request $request,$id){

        $tailieu = TaiLieu::find($id);

        $this->validate($request,
            [
                'LoaiTaiLieu' => 'required',
                'TomTat' => 'required|min:5'
            ],
            [
                'LoaiTaiLieu.required' => 'Bạn chưa chọn loại tài liệu',
                'TieuDe.min' => 'Tiêu đề quá ngắn (ít nhất 5 kí tự)',
                'TieuDe.max' => 'Tiêu đề quá dài (tối đa 50 kí tự)',
                'TieuDe.unique' => 'Tiêu đề đã tồn tại',
                'TomTat.required' => 'Hãy nhập tóm tắt cho tài liệu',
                'TomTat.min' => 'Tóm tắt quá ngắn (ít nhất 5 kí tự)',
            ]);

        $tailieu->TieuDe = $request->TieuDe;
        $tailieu->TieuDeKhongDau = changeTitle($request->TieuDe);
        $tailieu->idLoaiTaiLieu = $request->LoaiTaiLieu;
        $tailieu->TomTat = $request->TomTat;
        $tailieu->NoiDung = ""; 
        $tailieu->NoiBat = $request->NoiBat;

        if($request -> hasFile('Hinh')){
            
            $file = $request->file('Hinh');
            $extension = $file->getClientOriginalExtension();

            if($extension != 'jpg' && $extension != 'png' && $extension != 'gif' && $extension != 'jpeg' ){
                return redirect('admin/tailieu/add')->with('errormessage','Bạn chỉ được chọn file có định dạng: .jpg, .jpeg, .png, .gif');
            }

            $name = $file->getClientOriginalName();
            $Hinh = str_random(20)."_". $name;
            
            while(file_exists("upload/tailieu/images".$Hinh)){
                $Hinh = str_random(20)."_". $name;
            }
            //Xóa file cũ khi thay file mới!
            $file->move("upload/tailieu/images",$Hinh);

            //Đoạn này đang code thiếu đối với trường hợp sửa ảnh nhưng chưa có ảnh. Bắt buộc có ảnh mới edit được
            //unlink("upload/tailieu/images".$tailieu->Hinh);  
            $tailieu->Hinh = $Hinh;
            // echo $Hinh;
        }

        if($request -> hasFile('Teptin')){

            $filett = $request->file('Teptin');
            $extensiontt = $filett->getClientOriginalExtension();

            // Bo kiem tra extension
            // if($extensiontt != 'pdf' && $extensiontt != 'doc' && $extensiontt != 'docx'){
            //     return redirect('admin/tailieu/add')->with('errormessage','Bạn chỉ được chọn file có định dạng: pdf, doc, docx');
            // }

            $namett = $filett->getClientOriginalName();
            //$Teptin = str_random(20)."_". $namett;
            $Teptin = $namett;
            while(file_exists("upload/tailieu/".$Teptin)){
                //$Teptin = str_random(20)."_". $namett;
                $Teptin = $namett;
            }
            
            $filett->move("upload/tailieu",$Teptin);
            
            $tailieu->Teptin = $Teptin;
            // echo $Teptin;
        }

        $tailieu->save();
        return redirect('admin/tailieu/edit/'.$id)->with('vmessage','Sửa tài liệu thành công !');
    }

   
    public function getXoa($id){
        $tailieu = TaiLieu::find($id);
        $tailieu->delete();
        return redirect('admin/tailieu/danhsach')->with('vmessage','Đã xóa tài liệu thành công!');
    }

}
