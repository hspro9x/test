<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Sliders;

class SlidersController extends Controller
{
    //
    public function getDanhsach(){
    	$slide = Sliders::all();
    	return view('admin.slide.danhsach',['slide'=>$slide]);
    }
    public function getThem(){
    	return view('admin.slide.add');
    }

    public function postThem(Request $request){
    	
    	//Kiem tra thuoc tinh slide
    	$this->validate($request,
    		[
    			'Ten'=>'required',
    			'NoiDung'=>'required'
    		],
    		[
    			'Ten.required'=>'Bạn chưa nhập tên slide',
    			'NoiDung.required'=>'Bạn chưa nhập nội dung slide'
    		]);

    	$slide = new Sliders();
    	$slide->Ten = $request->Ten;
    	$slide->NoiDung = $request->NoiDung;
    	if($request->has('link'))
    		$slide->link = $request->link;

    	//Kiem tra hinh anh
        if($request -> hasFile('Hinh')){
            
            $file = $request->file('Hinh');
            $extension = $file->getClientOriginalExtension();

            if($extension != 'jpg' && $extension != 'png' && $extension != 'gif' && $extension != 'jpeg' && $extension != 'pdf' && $extension != 'docx' && $extension != 'doc' && $extension != 'xlsx' && $extension != 'xls' && $extension != 'ppt' && $extension != 'pptx'){
                return redirect('admin/tailieu/add')->with('errormessage','Bạn chỉ được chọn file có định dạng: .jpg, .jpeg, .png, .gif, .pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx');
            }

            $name = $file->getClientOriginalName();
            $Hinh = str_random(20)."_". $name;
            
            while(file_exists("upload/slide/".$Hinh)){
                $Hinh = str_random(20)."_". $name;
            }
            
            $file->move("upload/slide",$Hinh);
            
            $slide->Hinh = $Hinh;

            // echo $Hinh;
        }else{
            $slide->Hinh = "";
        }

        $slide->save(); 
        return redirect('admin/slide/add')->with('vmessage','Thêm slide thành công');
    }
    public function getSua($id){
    	$slide = Sliders::find($id);
        return view('admin.slide.edit',['slide'=>$slide]);
    }

    public function postSua(Request $request,$id){
        
    	$this->validate($request,
    		[
    			'Ten'=>'required',
    			'NoiDung'=>'required'
    		],
    		[
    			'Ten.required'=>'Bạn chưa nhập tên slide',
    			'NoiDung.required'=>'Bạn chưa nhập nội dung slide'
    		]);
		$slide = Sliders::find($id);
    	$slide->Ten = $request->Ten;
    	$slide->NoiDung = $request->NoiDung;

    	if($request->has('link'))
    		$slide->link = $request->link;

    	//Kiem tra hinh anh
        if($request -> hasFile('Hinh')){
            
            $file = $request->file('Hinh');

            //Kiem tra Ten tep tin va Extension cua tep tin upload.
            $name = $file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();

            //Kiem tra tep tin.
            if($extension != 'jpg' && $extension != 'png' && $extension != 'gif' && $extension != 'jpeg' && $extension != 'pdf' && $extension != 'docx' && $extension != 'doc' && $extension != 'xlsx' && $extension != 'xls' && $extension != 'ppt' && $extension != 'pptx'){
                return redirect('admin/tailieu/add')->with('errormessage','Bạn chỉ được chọn file có định dạng: .jpg, .jpeg, .png, .gif, .pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx');
            }
            
            $Hinh = str_random(20)."_". $name;
            
            while(file_exists("upload/slide/".$Hinh)){
                $Hinh = str_random(20)."_". $name;
            }
            unlink('upload/slide/'.$slide->Hinh);
            $file->move('upload/slide',$Hinh);
            
            $slide->Hinh = $Hinh;
            // echo $Hinh;
        }
        $slide->save(); 
        return redirect('admin/slide/edit/'.$id)->with('vmessage','Sửa slide thành công');
    }
    
    public function getXoa($id){
    	$slide = Sliders::find($id);
        $slide->delete();
        
        return redirect('admin/slide/danhsach')->with('vmessage','Đã xóa thành công: '.$slide->Ten);
    }
    
}
