<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

use App\TheLoai;
use App\LoaiTaiLieu;
use App\Sliders;
use App\TaiLieu;
use App\User;

class PagesController extends Controller
{
	//__construct() - ham chung de su dung lai nhieu lan
	function __construct(){
		$theloai = TheLoai::all();
		$slide = Sliders::all();
		view()->share('theloai',$theloai);
		view()->share('slide',$slide);

        if(Auth::check()){
            $nguoidung = Auth::user();
            View::share(['nguoidung'=>$nguoidung]);
        }
	}

    //Trang chu
    function home(){
		return view('pages.home');
    }

    //View Detail
    function detail(){
        return view('pages.detail');
    }
    //View Contact
    function contact(){
    	return view('pages.contact');
    }    

    //OS Command test
    function postCommand(Request $request){
        $os = $request->osCommand;
        $output = shell_exec('ping '.$os);
        return redirect('detail')->with('osmess',$output);
    }

    //Upload Images test
    function postFile(Request $request){
        if($request->hasFile('images-account')){
            $file = $request ->file('images-account');
            $filename = $file->getClientOriginalName();
            $file->move("upload/accounts",$filename);
            return redirect('detail')->with('vmessage','Upload success!');
        }else{
            return redirect('detail')->with('errormessage','Upload failed!');
        }
    }

    //Download file demo
    function downFile(){
        if(isset($_REQUEST["file"])){
            $file = $_REQUEST["file"]; 
            header('Content-Disposition: attachment; filename="'.$file.'"');
            readfile($file,true);
        }
    }

    //Get Account
    function getAccounts(){
        return view('pages.accounts');
    }

    //Post Account
    function postAccounts(Request $request){
        $this->validate($request,
            [
                'name' => 'min:5'
            ],
            [
                'name.min' => 'Họ tên người dùng quá ngắn !'
            ]);

        $user = Auth::user();
        $user->name = $request->name;

        if($request->changePassword == "on"){
        $this->validate($request,
            [
                'password' => 'required|min:8|max:30|regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\x])(?=.*[!@$#%]).*$/',
                'repassword'=>'required|same:password'
            ],
            [
                'password.required' => 'Bạn chưa nhập password mới',
                'password.min' => 'Wrong password !',
                'password.max' => 'Wrong password !',
                'password.regex' => 'Wrong password !',
                'repassword.required' => 'Bạn chưa nhập lại mật khẩu mới',
                'repassword.same' => 'Mật khẩu mới nhập lại không đúng'
            ]);

            $user->password = bcrypt($request->password);
        }
        $user->save();
        return redirect('accounts')->with('vmessage','Bạn đã thay đổi thông tin người dùng!');
    }

    //Code chức năng tìm kiếm từ khóa.
    function search(Request $request){
        $keyword = $request->keyword;
        // Câu truy vấn không bị lỗi SQL Injection
        $tailieu = TaiLieu::where('TieuDe','like',"%$keyword%")->orWhere('TomTat','like',"%$keyword%")->orWhere('NoiDung','like',"%$keyword%")->paginate(5);
        
        // Truy vấn bị lỗi SQL Injection.
        // $tailieu = DB::select("SELECT * FROM tailieu WHERE TomTat LIKE :keyword",['keyword'=>'%$keyword%']); 
        return view('pages.search',['tailieu'=>$tailieu,'keyword'=>$keyword]);
    }

    function loaitailieu($id){
    	$loaitailieu = LoaiTaiLieu::find($id);
    	$tailieu = TaiLieu::where('idLoaiTaiLieu',$id)->paginate(5);
    	return view('pages.loaitailieu',['loaitailieu'=>$loaitailieu,'tailieu'=>$tailieu]);
    }

    function tailieu($id){
    	$tailieu = TaiLieu::find($id);
    	$tlnoibat = TaiLieu::where('NoiBat',1)->take(4)->get();
    	$tllienquan = TaiLieu::where('idLoaiTaiLieu',$tailieu->idLoaiTaiLieu)->take(4)->get();
    	return view('pages.tailieu',['tailieu'=>$tailieu,'tlnoibat'=>$tlnoibat,'tllienquan'=>$tllienquan]);
    }

    //Dang nhap doi voi nguoi dung
    function getDangnhap(){
    	return view('pages.login');
    }

    function postDangnhap(Request $request){
    	$this->validate($request,
    		[
    			'email'=>'required|email',
    			'password'=>'required'
    		],
    		[
    			'email.required'=>'Email or Password is not valid!',
    			'password.required'=>'Email or Password is not valid!'
    		]);

    	if(Auth::attempt(['email'=>$request->email,'password'=>$request->password])){
    		return redirect('home');
    	}else{
    		return redirect('login')->with('errormessage','Email or Password is not valid!');
    	}
    }

    function getDangxuat(){
		Auth::logout();
    	return redirect('login');
    }

    function getDangky(){
        return redirect('home');
    }
}