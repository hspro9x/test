<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\TheLoai;
use App\LoaiTaiLieu;

class AjaxController extends Controller
{
	public function getLoaiTaiLieu($idTheLoai){
		$loaitailieu = LoaiTaiLieu::where('idTheLoai',$idTheLoai)->get();

		foreach ($loaitailieu as $lt) {
			# code...
			echo "<option value='".$lt->id."'>".$lt->Ten."</option>";
		}
	}

}