<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\TaiLieu;
use App\User;

class Comment extends Model
{
    //
    protected $table = "Comment";

    //Kiem tra comment thuoc tai lieu nao.
    public function tailieu(){
    	return $this->belongsTo('App\TaiLieu','idTaiLieu','id');
    }

    //Kiem tra comment thuoc User nao.
    public function user(){
    	return $this->belongsTo('App\User','idUser','id');
    }
}
