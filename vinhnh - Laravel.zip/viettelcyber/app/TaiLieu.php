<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TaiLieu extends Model
{
    //
    protected $table = "TaiLieu";
	
	// protected $fillable = [
	//         'name', 'teptin'
	// ];
    public function loaitailieu(){
    	return $this->belongsTo('App\LoaiTaiLieu','idLoaiTaiLieu','id');
    }

    //Lấy ra danh sách comment ứng với tài liệu tương ứng.
    public function comment(){
    	return $this->hasMany('App\Comment','idTaiLieu','id');
    }
}
