<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TheLoai extends Model
{
    //
    protected $table = "TheLoai";

    public function loaitailieu(){
    	return $this->hasMany('App\LoaiTaiLieu','idTheLoai','id');
    }

    public function tailieu(){
    	return $this->hasManyThrough('App\TaiLieu','App\LoaiTaiLieu','idTheLoai','idLoaiTaiLieu','id');
    }
}
