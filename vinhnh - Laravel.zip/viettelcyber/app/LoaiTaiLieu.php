<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoaiTaiLieu extends Model
{
    //
    protected $table = "LoaiTaiLieu";

    public function theloai(){
    	return $this->belongsTo('App\TheLoai','idTheLoai','id');
    }

    public function tailieu(){
    	return $this->hashMany('App\TaiLieu','idLoaiTaiLieu','id');
    }
}
