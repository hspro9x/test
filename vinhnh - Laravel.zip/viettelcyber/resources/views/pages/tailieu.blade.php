@extends('layout.index')
@section('content')

<!-- Page Content -->
<div class="container">
    <div class="row">
        <!-- Blog Post Content Column -->
        <div class="col-lg-9">
            <!-- Blog Post -->
            <!-- Title -->
            <h1>{{$tailieu->TieuDe}}</h1>
            <!-- Author -->
            <p class="lead">
                bởi <a href="home">admin</a>
            </p>    
            <!-- Preview Image -->
            <img class="img-responsive" src="upload/tailieu/images/{{$tailieu->Hinh}}" alt="">
            <!-- Date/Time -->
            <br><p><span class="glyphicon glyphicon-time"></span> {{$tailieu->created_at}}</p>
            <hr>
            <!-- Post Content -->
            <p class="lead">
                {!! $tailieu->TomTat !!} 
            </p>

            <td>
                <a href="upload/tailieu/{{$tailieu->Teptin}}">
                    <button type="button"> Tài liệu đính kèm </button>
                </a>
            </td>
            <hr>
            <!-- Blog Comments -->
            <!-- Comments Form -->
            {{-- Cap nhat them phan comment --}}
            
            @if(Auth::user())
            <div class="well">
                @if(session('vmessage'))
                    {{session('vmessage')}}
                @endif
                <h4>Bình luận tại đây <span class="glyphicon glyphicon-pencil"></span></h4>
                <form action="comment/{{$tailieu->id}}" method="POST" role="form">
                    <input type="hidden" name="_token" value="{{csrf_token()}}" />
                    <div class="form-group">
                        <textarea class="form-control" name="NoiDung" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary"> Gửi bình luận</button>
                </form>
            </div>
            @endif
            <hr>

            <!-- Posted Comments -->
            <!-- Comment -->
            @foreach($tailieu->comment as $binhluan)
            <div class="media">
                <a class="pull-left" href="thanhvien/{{$binhluan->user->id}}">
                    <img class="media-object" src="http://placehold.it/64x64" alt="">
                </a>
                <div class="media-body">
                    
                    <!-- XSS tai $binhluan->user->name -->
                    <h4 class="media-heading">{!! $binhluan->user->name !!}/
                        <small>{{$binhluan->created_at}}</small>
                    </h4>
                    {{$binhluan->NoiDung}}
                </div>
            </div>
            @endforeach
        </div>

        <!-- Blog Sidebar Widgets Column -->
        <div class="col-md-3">

            <div class="panel panel-default">
                <div class="panel-heading"><b>Tài liệu liên quan</b></div>
                <div class="panel-body">
                    @foreach($tllienquan as $tt)
                    <!-- item -->
                    <div class="row" style="margin-top: 10px;">
                        <div class="col-md-5">
                            <a href="tailieu/{{$tt->id}}/{{$tt->TieuDeKhongDau}}.html">
                                <img class="img-responsive" src="upload/tailieu/{{$tt->Hinh}}" alt="">
                            </a>
                        </div>
                        <div class="col-md-7">
                            <a href="tailieu/{{$tt->id}}/{{$tt->TieuDeKhongDau}}.html"><b>{{$tt->TieuDe}}</b></a>
                        </div>
                        <p>{{$tt->TomTat}}</p>
                        <div class="break"></div>
                    </div>
                    <!-- end item -->
                    @endforeach
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading"><b>Tài liệu nổi bật</b></div>
                <div class="panel-body">
                    @foreach($tlnoibat as $tt)
                    <!-- item -->
                    <div class="row" style="margin-top: 10px;">
                        <div class="col-md-5">
                            <a href="tailieu/{{$tt->id}}/{{$tt->TieuDeKhongDau}}.html">
                                <img class="img-responsive" src="upload/tailieu/{{$tt->Hinh}}" alt="">
                            </a>
                        </div>
                        <div class="col-md-7">
                            <a href="tailieu/{{$tt->id}}/{{$tt->TieuDeKhongDau}}.html"><b>{{$tt->TieuDe}}</b></a>
                        </div>
                        <p>{{$tt->TomTat}}</p>
                        <div class="break"></div>
                    </div>
                    <!-- end item -->
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->
</div>
<!-- end Page Content -->
@endsection