<!DOCTYPE html>
<html>
<head>
    <title>Detail - Vinh Nguyen</title>
    <link rel="icon" href="icon.jpg">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> 
</head>
<body>
    <br><br><br>
    <div class="container">
        <div class="d-flex justify-content-center p-2">
            
            <h2>About me</h2>
            <ul>
                <li>Name: Nguyen Huy Vinh</li>
                <li>DOB: 30/08/1996</li>
                <li> @lavie3k </li>
            </ul>
        </div>
        <hr/>
        <div class="d-flex justify-content-center p-2">
            <ul class="list-group list-group-horizontal-md">
                <li class="list-group-item"><a href="https://github.com/" target="_blank">github</a></li>
                <li class="list-group-item"><a href="https://www.linkedin.com/" target="_blank">linkedin</a></li>
                <li class="list-group-item"><a href="https://www.facebook.com/" target="_blank">facebook</a></li>
                <li class="list-group-item"><a href="https://wordpress.com" target="_blank">wordpress</a></li>
            </ul>
        </div>
        <a type="button" href="home">Back to home</a>
    </div>
</body>
</html>
