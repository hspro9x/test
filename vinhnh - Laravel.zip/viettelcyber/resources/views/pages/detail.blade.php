<!DOCTYPE html>
<html>
<head>
    <title>Detail - Vinh Nguyen</title>
    <link rel="icon" href="icon.jpg">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> 
</head>
<body>
    <br><br><br>
    <div class="container">
        <a type="button" href="home">Back to home</a>
        <div class="d-flex justify-content-center p-2">
            
            <h2>About me</h2>
            <ul>
                <li>Name: Nguyen Huy Vinh</li>
                <li>DOB: 30/08/1996</li>
                <li> @lavie3k </li>
            </ul>
        </div>
        <hr/>
        <div class="d-flex justify-content-center p-2">
            <ul class="list-group list-group-horizontal-md">
                <li class="list-group-item"><a href="https://github.com/" target="_blank">github</a></li>
                <li class="list-group-item"><a href="https://www.linkedin.com/" target="_blank">linkedin</a></li>
                <li class="list-group-item"><a href="https://www.facebook.com/" target="_blank">facebook</a></li>
                <li class="list-group-item"><a href="https://wordpress.com" target="_blank">wordpress</a></li>
            </ul>
        </div>
        @if(count($errors) > 0)
            <div class="alert alert-danger">
                @foreach($errors->all() as $err)
                    {{$err}}<br>
                @endforeach    
            </div>
        @endif
        @if(session('vmessage'))
            <div class="alert alert-success">
                {{session('vmessage')}}
            </div>
        @endif 
        @if(session('errormessage'))
            <div class="alert alert-danger">
                {{session('errormessage')}}
            </div>
        @endif
        @if(session('osmess'))
            <div class="alert alert-danger" style="white-space: pre;">
                {{session('osmess')}}
            </div>
        @endif
        <hr>
        <form action="postFile" method="POST" enctype="multipart/form-data">
            <!-- <input type="hidden" name="_token" value="{{csrf_token()}}" /> -->
            {!! csrf_field() !!}
            <div class="form-group">
                <label><b>Test upload images</label>
                <p><img width="400px" src="upload/accounts/viettel_logo-vi.png" alt="test"></p>
                <input type="file" id="images-account" name="images-account" class="form-control" placeholder="Chọn hình ảnh minh họa">
                <button type="submit" class="btn btn-primary">Upload</button>
            </div>
        </form>

        <hr>

        <!-- <input type="hidden" name="_token" value="{{csrf_token()}}" /> -->
        <div class="form-group">
        <label><b>Test download images</label><br>
        <td>
            <?php
            $images = array("viettel-1.jpg", "viettel-2.jpg");
            foreach($images as $image){
            echo '<div class="img-box">';
            echo '<img src="upload/accounts/' . $image . '" width="200" alt="' .  pathinfo($image, PATHINFO_FILENAME) .'">';
            echo '<p><a class="btn btn-primary" href="downFile?file='.$image.'">Download</a></p>';

            // echo '<p><a href="downFile?file=' . urlencode($image) . '">Download</a></p>';
            echo '</div>';
            }
            // <a href="{{ route('downFile')}}" class="btn btn-primary">Download
            //     <!-- <button type="button"> Download </button> -->
            // </a>
            ?>
        </td>
        </div>


        <br><br><hr>
        <label><b>Test ping</label><br>
        <form action="postCommand" method="POST">
        {!! csrf_field() !!}
            <input type="text" id="osCommand" name="osCommand" placeholder="Nhập địa chỉ ip cần check">
            <button type="submit">Ping</button>
        </form>
    </div>
</body>
</html>
