
@extends('admin.layout.index')
@section('content')

<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header"> Tài liệu
                    <small>{{$tailieu->TieuDe}}</small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <div class="col-lg-7" style="padding-bottom:120px">


                {{-- Thông báo sự kiện --}}
                @if(count($errors) > 0)
                    <div class="alert alert-danger">
                        @foreach($errors->all() as $err)
                            {{$err}}<br>
                        @endforeach    
                    </div>
                @endif

                @if(session('vmessage'))
                    <div class="alert alert-success">
                        {{session('vmessage')}}
                    </div>
                @endif

                @if(session('errormessage'))
                    <div class="alert alert-danger">
                        {{session('errormessage')}}
                    </div>
                @endif
                
                <form action="admin/tailieu/edit/{{$tailieu->id}}" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="{{csrf_token()}}" />

                    <div class="form-group">
                        <label>Thể loại</label>
                        <select class="form-control" name="TheLoai" id="TheLoai">
                            @foreach($theloai as $tl)
                                <option 
                                @if($tailieu->loaitailieu->theloai->id == $tl->id)
                                    {{"selected"}}
                                @endif
                                value="{{$tl->id}}">{{$tl->Ten}}</option>
                            @endforeach
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Loại tài liệu</label>
                        <select class="form-control" name="LoaiTaiLieu" id="LoaiTaiLieu">
                            @foreach($loaitailieu as $lt)
                                <option 
                                @if($tailieu->loaitailieu->id == $lt->id)
                                    {{"selected"}}
                                @endif
                                value="{{$lt->id}}">{{$lt->Ten}}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Tiêu đề tài liệu</label>
                        <input class="form-control" name="TieuDe" placeholder="Nhập tên tài liệu" value="{{$tailieu->TieuDe}}"/>
                    </div>

                    <div class="form-group">
                        <label>Tóm tắt</label>
                        <textarea name="TomTat" class="form-control" rows="3">
                            {{$tailieu->TomTat}}
                        </textarea>
                    </div>
                    {{-- <div class="form-group">
                        <label>Nội dung</label>
                        <textarea name="NoiDung" class="form-control" rows="4">
                            {{$tailieu->NoiDung}}
                        </textarea>
                    </div> --}}

                    <div class="form-group">
                        <label>Hình minh họa</label>
                        <p><img width="400px" src="upload/tailieu/images/{{$tailieu->Hinh}}"></p>
                        <input type="file" name="Hinh" class="form-control" placeholder="Chọn hình ảnh minh họa">
                    </div>

                    {{-- Đang code chức năng Sửa tài liệu --}}
                    <div class="form-group">
                        <label>File tài liệu</label>
                        <p><a href="resources/upload/{{$tailieu->Teptin}}">
                        <input type="file" name="Teptin" class="form-control" >
                    </div>

                    <div class="form-group">
                        <label>Nổi bật &emsp;</label>
                        <label class="radio-inline">
                            <input name="NoiBat" value="1" 
                            @if($tailieu->NoiBat == 1)
                                {{"checked"}} 
                            @endif
                            type="radio">Có
                        </label>
                        <label class="radio-inline">
                            <input name="NoiBat" value="0" 
                            @if($tailieu->NoiBat == 0)
                                {{"checked"}} 
                            @endif
                            type="radio">Không
                        </label>
                    </div>

                    {{-- <button style="color: blue" type="submit" id="TaiLieu" class="btn btn-default">Đính kèm tài liệu</button> --}}
                    
                    <hr>
                    <button type="submit" class="btn btn-default">Sửa</button>
                    <button type="reset" class="btn btn-default">Reset</button><hr>
                <form>
            </div>
        </div>
        <!-- /.row -->
        
        {{-- Bảng danh sách bình luận --}}
        <!--row -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header"> Bình luận
                    <small> Danh sách bình luận</small>
                </h1>
            </div>

            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr align="center">
                        <th>ID</th>
                        <th>Người dùng</th>
                        <th>Nội dung</th>
                        <th>Ngày đăng</th>
                        <th>Delete</th>
                        <th>Edit</th>
                    </tr>
                </thead>

                <tbody>
                    @foreach($tailieu->comment as $binhluan)
                    <tr class="odd gradeX" align="center">
                        <td>{{$binhluan->id}}</td>
                        <td>{{$binhluan->id}}</td>
                        <td>{{$binhluan->NoiDung}}</td>
                        <td>{{$binhluan->created_at}}</td>
                        <td class="center"><i class="fa fa-trash-o fa-fw"></i><a href="admin/comment/delete/{{$binhluan->id}}/{{$tailieu->id}}"> Delete</a></td>
                        <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="admin/comment/edit/{{$binhluan->id}}/{{$tailieu->id}}"> Edit</a></td>
                    </tr>
                    @endforeach
                </tbody>

            </table>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

@endsection

@section('script')
    {{-- <script>alert(1);</script> --}}
    {{-- Bắt sự kiện khi chọn THỂ LOẠI để trả về danh sách LOẠI TÀI LIỆU tương ứng --}}
    <script>
        $(document).ready(function(){
            $("#TheLoai").change(function(){
                var idTheLoai = $(this).val();
                // alert(idTheLoai);
                $.get("admin/ajax/loaitailieu/"+idTheLoai,function(data){
                    $("#LoaiTaiLieu").html(data);
                });
            });
        });

    </script>
@endsection