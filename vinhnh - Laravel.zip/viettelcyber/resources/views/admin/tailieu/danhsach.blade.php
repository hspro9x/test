
@extends('admin.layout.index')
@section('content')

<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Quản lý tài liệu
                    <small>Danh sách tài liệu</small>
                </h1>
            </div>

            {{-- Thông báo sự kiện --}}
            @if(count($errors) > 0)
                <div class="alert alert-danger">
                    @foreach($errors->all() as $err)
                        {{$err}}<br>
                    @endforeach    
                </div>
            @endif

            @if(session('vmessage'))
                <div class="alert alert-success">
                    {{session('vmessage')}}
                </div>
            @endif

            @if(session('errormessage'))
                <div class="alert alert-danger">
                    {{session('errormessage')}}
                </div>
            @endif

            <!-- /.col-lg-12 -->
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr align="center">
                        <th>ID</th>
                        <th>Tiêu đề</th>
                        <th>Tóm tắt</th>
                        <th>Thể loại</th>
                        <th>Loại tài liệu</th>
                        <th>Số lượt xem</th>
                        <th>Nổi bật</th>
                        <th>Delete</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($tailieu as $tt)
                    <tr class="odd gradeX" align="center">
                        <td>{{$tt->id}}</td>
                        <td>
                            <p>{{$tt->TieuDe}}</p>
                            <img width="100px" src="upload/tailieu/images/{{$tt->Hinh}}" />
                        </td>
                        <td>{{$tt->TomTat}}</td>
                        <td>{{$tt->loaitailieu->theloai->Ten}}</td>
                        <td>{{$tt->loaitailieu->Ten}}</td>
                        <td>{{$tt->SoLuotXem}}</td>
                        <td>
                            {{-- {{$tt->NoiBat}} --}}
                            @if($tt->NoiBat ==0)
                                {{'Không'}}
                            @else
                                {{'Có'}}
                            @endif
                        </td>

                        <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="admin/tailieu/delete/{{$tt->id}}"> Delete</a></td>
                        <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="admin/tailieu/edit/{{$tt->id}}">Edit</a></td>
                    </tr>

                    @endforeach
                </tbody>
            </table>
        </div>
        <!-- /.row -->




        
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

@endsection