@extends('admin.layout.index')
@section('content')

<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header"> Thành viên
                    <small> Danh sách thành viên</small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr align="center">
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Telephone</th>                        
                        <th>Permission</th>
                        <th>Delete</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($user as $thanhvien)
                    <tr class="odd gradeX" align="center">
                        <td>{{$thanhvien->id}}</td>
                        <td>{{$thanhvien->name}}</td>
                        <td>{{$thanhvien->email}}</td>
                        <td>{{$thanhvien->sodienthoai}}</td>
                        <td>
                            @if($thanhvien->quyen == 1)
                                {{'Admin'}}
                            @else {{'Người dùng'}}
                            @endif
                        </td>
                        <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="admin/user/delete/{{$thanhvien->id}}"> Delete</a></td>
                        <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="admin/user/edit/{{$thanhvien->id}}"> Edit</a></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            {{-- <a href="admin/user/add">Thêm thành viên</a> --}}
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

@endsection