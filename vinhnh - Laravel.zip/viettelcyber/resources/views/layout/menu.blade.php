{{-- Menu --}}
<div class="col-md-3 ">
    <ul class="list-group" id="menu">
        <li href="#" class="list-group-item menu1 active">
        	Danh sách thể loại
        </li>


        @foreach($theloai as $tl)
            @if(count($tl->loaitailieu) >= 0)
            <li href="#" style="color:blue" class="list-group-item menu1">
            	<i>{{$tl->Ten}}</i>
            </li>
            <ul>
                @foreach($tl->loaitailieu as $lt)
        		<li class="list-group-item">
        			<a href="loaitailieu/{{$lt->id}}/{{$lt->TenKhongDau}}.html">{{$lt->Ten}}</a>
        		</li>
                @endforeach
            </ul>
            @endif
        @endforeach
    </ul>
</div>